//I WAS GONNA USE THESE BUT YEA, DIDNT HAPPEN, SORRY
//ALSO THANKS MATT YOU ARE A LEGEND 

/* 828472 COMP20007 Project 1

Code was taken from Matt Farrugia from Workshop 2
Modified to suit stack functions

*/
/*
#include <stdlib.h>
#include <assert.h>
#include "stack.h"
#include "list.h"

*/
/* * * *
 * FUNCTION DEFINITIONS
 */

/*
//push stack from the start
// add an element to the front of a stack

void push_start(List *list, int data) {
	return (list_add_start(List *list, int data));
}

//pop stack from the start
int stack_remove_start(List *list) {
	return (list_remove_start(List *list));
}


// return the number of elements contained in a stack
int stack_size(List *list) {
	return list_size(List *list);
}


// returns whether the stack contains no elements (true) or some elements (false)
bool stack_is_empty(List *list) {
	return (list_is_empty(List *list));
}
*/
/* 828472 COMP20007 Project 1

Code was taken from Matt Farrugia from Workshop 2
Modified to suit list functions


*/

#include <stdbool.h>
typedef struct node Node;

// a list node points to the next node in the list, and to some data
struct node {
	Node *next;
	int data;
};

// a list points to its first and last nodes, and stores its size (num. nodes)
struct list {
	Node *head;
	Node *tail;
	int size;
};

typedef struct list List;

// create a new list and return a pointer to it
List *new_list();

// destroy a list and free its memory
void free_list(List *list);

// add an element to the front of a list
// this operation is O(1)
void list_add_start(List *list, int data);

// add an element to the back of a list
// this operation is O(1)
void list_add_end(List *list, int data);

// remove and return the front data element from a list
// this operation is O(1)
// error if the list is empty (so first ensure list_size() > 0)
int list_remove_start(List *list);

// remove and return the final data element in a list
// this operation is O(n), where n is the number of elements in the list
// error if the list is empty (so first ensure list_size() > 0)
int list_remove_end(List *list);

// return the number of elements contained in a list
int list_size(List *list);

// returns whether the list contains no elements (true) or some elements (false)
bool list_is_empty(List *list);